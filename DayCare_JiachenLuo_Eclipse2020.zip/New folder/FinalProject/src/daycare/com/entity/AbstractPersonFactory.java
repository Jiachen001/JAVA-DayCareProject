package daycare.com.entity;

public abstract class AbstractPersonFactory {

    public abstract Person getObject();
}
